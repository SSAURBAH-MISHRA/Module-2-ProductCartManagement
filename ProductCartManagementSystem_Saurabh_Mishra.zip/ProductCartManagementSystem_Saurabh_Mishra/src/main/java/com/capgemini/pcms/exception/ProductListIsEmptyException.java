package com.capgemini.pcms.exception;

@SuppressWarnings("serial")
public class ProductListIsEmptyException extends RuntimeException {

	// Constructor of ProductListIsEmptyException class with a String parameter.
	public ProductListIsEmptyException(String message) {
		super(message);
	}

}
