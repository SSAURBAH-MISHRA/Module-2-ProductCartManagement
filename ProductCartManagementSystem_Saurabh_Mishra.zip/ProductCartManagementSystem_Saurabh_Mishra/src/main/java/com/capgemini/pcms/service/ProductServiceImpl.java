package com.capgemini.pcms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.pcms.beans.Product;
import com.capgemini.pcms.dao.ProductRepoImpl;
import com.capgemini.pcms.exception.DuplicateProductIdException;
import com.capgemini.pcms.exception.ProductIdDoesNotExistException;
import com.capgemini.pcms.exception.ProductListIsEmptyException;

@Service
public class ProductServiceImpl implements IProductService {

	/* The @Autowired annotation is used to autowire bean on the setter method. */
	@Autowired(required = true)
	ProductRepoImpl productrepo; // reference of ProductRepoImpl class.

	@Override
	// method definition for creating a product.
	public Product create(Product product) {
		if (productrepo.get(product.getId()) != null) {
			throw new DuplicateProductIdException("Exception: DUPLICATE PRODUCT ID"); // Passing string as a message.
		}
		return productrepo.create(product);
	}

	@Override
	// method definition for updating a product using product id.
	public Product update(String id, Product product) {
		return productrepo.update(id, product);
	}

	@Override
	// method definition for deleting a product using product id.
	public Product delete(String id) {
		if (productrepo.get(id) == null) {
			throw new ProductIdDoesNotExistException("Exception: PRODUCT ID DOES NOT EXIST");
		}
		return productrepo.delete(id);
	}

	@Override
	// method definition for finding all products.
	public List<Product> findAll() {
		if (productrepo.findAll().size() == 0) {
			throw new ProductListIsEmptyException("Exception: LIST IS EMPTY");
		}
		return productrepo.findAll();
	}

	@Override
	// method definition for finding one product using product id.
	public Product get(String id) {
		if (productrepo.get(id) == null) {
			throw new ProductIdDoesNotExistException("Exception: PRODUCT ID DOES NOT EXIST");
		}
		return productrepo.get(id);
	}

}
