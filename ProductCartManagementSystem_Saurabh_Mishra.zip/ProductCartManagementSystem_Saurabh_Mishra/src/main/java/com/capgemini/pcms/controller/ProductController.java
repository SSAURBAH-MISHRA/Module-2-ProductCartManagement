package com.capgemini.pcms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.pcms.beans.Product;
import com.capgemini.pcms.service.ProductServiceImpl;

/* Refer  file(src/main/resources/application.properties) for changing/using database name, username, password and server.port*/

// @RestController annotation is applied here to mark this class as a request handler.
@RestController
public class ProductController {

	@Autowired(required = true)
	private ProductServiceImpl productService; // reference of ProductServiceImpl class.

	@RequestMapping(method = RequestMethod.POST, value = "/createProduct")
	public Product create(@Valid @RequestBody Product product) {
		return productService.create(product);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/updateproduct/{id}")
	public Product update(@Valid @PathVariable String id, @RequestBody Product product) {
		return productService.update(id, product);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteproduct/{id}")
	public Product delete(@PathVariable String id) {
		return productService.delete(id);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/products")
	public List<Product> findAll() {
		return productService.findAll();
	}

	@RequestMapping(method = RequestMethod.GET, value = "/products/{id}")
	public Product get(@PathVariable String id) {
		return productService.get(id);
	}
}
