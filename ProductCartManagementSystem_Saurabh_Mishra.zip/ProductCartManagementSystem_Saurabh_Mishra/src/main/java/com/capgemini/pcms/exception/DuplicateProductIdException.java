package com.capgemini.pcms.exception;

@SuppressWarnings("serial")
public class DuplicateProductIdException extends RuntimeException {

	// Constructor of DuplicateProductIdException class with a String parameter.
	public DuplicateProductIdException(String message) {
		super(message);
	}

}
