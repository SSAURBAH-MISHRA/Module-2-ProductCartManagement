package com.capgemini.pcms.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.pcms.beans.Product;

@Service
public interface IProductService {

	// method declaration for creating a product.
	public Product create(Product product);

	// method declaration for updating a product using product id.
	public Product update(String id, Product product);

	// method declaration for deleting a product using product id.
	public Product delete(String id);

	// method declaration for finding all products.
	public List<Product> findAll();

	// method declaration for finding one product using product id.
	public Product get(String id);

}
