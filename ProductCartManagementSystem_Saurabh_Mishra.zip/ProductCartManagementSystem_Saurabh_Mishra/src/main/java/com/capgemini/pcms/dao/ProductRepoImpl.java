package com.capgemini.pcms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.pcms.beans.Product;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo {

	@PersistenceContext
	private EntityManager entityManager;
	/*
	 * EntityManager is used to access a database. Here it is used to manage
	 * persistent entity instances, to find entities by their primary key identity,
	 * and to query over all entities.
	 */

	@Override
	@Transactional
	// method defintion for creating a product.
	public Product create(Product product) {

		entityManager.persist(product);
		return product;

	}

	@Override
	@Transactional
	// method definition for updating a product using product id.
	public Product update(String id, Product product) {

		entityManager.merge(product);
		entityManager.flush();
		return product;

	}

	@Override
	@Transactional
	// method definition for deleting a product using product id.
	public Product delete(String id) {

		Product product = entityManager.find(Product.class, id);
		entityManager.remove(product);
		entityManager.flush();
		return product;

	}

	@Override
	@Transactional
	// method definition for finding all the products.
	public List<Product> findAll() {

		/*
		 * TypedQuery<Product> instance is used to prepare a query for execution and
		 * specifying the type of the query result.
		 */
		TypedQuery<Product> query = entityManager.createQuery("select prod from Product prod ", Product.class);
		List<Product> list = query.getResultList();
		System.out.println("inside find all:" + list);
		return list;

	}

	@Override
	@Transactional
	// method definition for finding one product using product id.
	public Product get(String id) {

		Product product = entityManager.find(Product.class, id);
		if (product == null)
			return null;
		product.setId(id);
		return product;

	}

}
