package com.capgemini.pcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementSystemSaurabhMishraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementSystemSaurabhMishraApplication.class, args);
	}

}
