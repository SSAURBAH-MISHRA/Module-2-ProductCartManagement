package com.capgemini.pcms.exception;

@SuppressWarnings("serial")
public class ProductIdDoesNotExistException extends RuntimeException {

	// Constructor of ProductIdDoesNotExistException class with a String parameter.
	public ProductIdDoesNotExistException(String message) {
		super(message);
	}

}
