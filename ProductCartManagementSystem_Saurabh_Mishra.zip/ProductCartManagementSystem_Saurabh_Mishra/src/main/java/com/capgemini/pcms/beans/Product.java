package com.capgemini.pcms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

//pojo-class
@Entity
@Table(name = "Product")
public class Product {

	public Product() {
		super();
	}

	// Product Id as PRIMARY KEY.
	@Id
	@Column(name = "Id",length=20)
	private String id;

	// Product Name.
	@Column(name = "Name",length=20)
	@NotNull(message = "Product name must not be null.")
	private String name;

	// Product Model.
	@Column(name = "Model",length=20)
	@NotNull(message = "Product model must not be null.")
	private String model;

	// Product Price.
	@Column(name = "Price")
	private int price;

	// getter-setter of all the fields
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	// Parameterized constructor of Product Class.
	public Product(String id, String name, String model, int price) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.price = price;
	}

}
