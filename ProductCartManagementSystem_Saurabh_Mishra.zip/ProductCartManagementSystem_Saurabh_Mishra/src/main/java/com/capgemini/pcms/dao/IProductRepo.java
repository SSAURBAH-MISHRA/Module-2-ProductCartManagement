package com.capgemini.pcms.dao;

import java.util.List;

import com.capgemini.pcms.beans.Product;

public interface IProductRepo {

	// method declaration for creating a product.
	public Product create(Product product);

	// method declaration for updating a product using product id.
	public Product update(String id, Product product);

	// method declaration for deleting a product using product id.
	public Product delete(String id);

	// method declaration for finding all the products.
	public List<Product> findAll();

	// method declaration for finding one product using product id.
	public Product get(String id);
}
